#define Version "M5_UI v1.1"
/*

simple menu for (M5Stack) TFT screens
#####################################

- has a small memory footprint, all other libraries uses to much memory
- only for visualisation purposes (no input possible)



*/
#define __FILENAME__ (strrchr(__FILE__, '\\') ? strrchr(__FILE__, '\\') + 1 : __FILE__)

#include <M5Stack.h>
#include <Arduino.h>

#include "Display.h"
// #include "TFTTerminal.h"
// LCD Status
bool LCD = true;

// TODO TEST                                                                                .
// TODO TEST                                                                                .
char *getAllFreeHeap()
{
  static char freeH[80]{}; // returns the formated free heap space
  sprintf(freeH, "Size:%.2fkB Free:%.2fkB Min:%.2fkB Max:%.2fkB",
          ESP.getHeapSize() / 1024.0,
          ESP.getFreeHeap() / 1024.0,
          ESP.getMinFreeHeap() / 1024.0,
          ESP.getMaxAllocHeap() / 1024.0);
  return freeH;
}

// TODO TEST                                                                                .
// TODO TEST                                                                                .
void printFreeHeap() // for debugging issues
{
  Serial.println(getAllFreeHeap());
}

void setup()
{
  M5.begin();
  M5.Power.begin();
  Serial.begin(115200);

  Serial.println("Press some serial key or M5 Button B to start program"); // DEBUG
  M5.Lcd.println("Press some serial key or M5 Button B to start program");
  while (Serial.available() == 0)
  {
    M5.update();
    if (M5.BtnB.wasPressed())
    { // if M5 Buttons B was pressed, then also start...
      break;
    }
  }

  UI_setupTFT(); // INFO IMPORTANT MUST CALLED IN MAIN SETUP FIRST !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
}
uint32_t counter = 0;
void loop()
{
  UI_doHandleTFT(REFRESH_RATE);

  char cstr[16];

  static unsigned long refreshIconsPM = 0;
  unsigned long refreshIconsCM = millis();
  if (refreshIconsCM - refreshIconsPM >= 1000) // * random(2, 30))
  {
    itoa(counter++, cstr, 10);
    refreshIconsPM = refreshIconsCM;
    TerminalPrint(Terminal, NONE, cstr);

    if (random(100) > 50)
      TerminalPrint(Terminal, WARNING, "SuperWarnung");
    if (random(2090) > 50)
      TerminalPrint(Terminal, ERROR, "       SuperError");
    if (random(300) > 90)
      TerminalPrint(Terminal, INFO, "__________________SuperINFO");
    // if (random(700) > 150)
    //   TerminalPrint(Terminal, NONE, "_____________________SuperNONE");
    // if (random(110) > 20)
    //   TerminalPrint(Terminal, NONE, "_VERRY LONG MESSAGE 34959573195719458"); // max length of a single line

    printFreeHeap();
  }
}